﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;


namespace MathWizard.Controllers
{
    public class MathController : Controller

    {
        [HttpGet]
        public ViewResult calculator()
        {
            return View("calculator");
        }

        [HttpPost]        
        public IActionResult Add(string firstOperand, string secondOperand){

            double firstDoubleOperand = Convert.ToDouble(firstOperand);
            double secondDoubleOperand = Convert.ToDouble(secondOperand);
            double result = firstDoubleOperand + secondDoubleOperand;

            ViewData["Message"] = $"{firstDoubleOperand} + {secondDoubleOperand} = {result}";

            return View();
        }

        [HttpPost]
        public IActionResult Subtract(string firstOperand, string secondOperand){

            double firstDoubleOperand = Convert.ToDouble(firstOperand);
            double secondDoubleOperand = Convert.ToDouble(secondOperand);
            double result = firstDoubleOperand - secondDoubleOperand;
            
            ViewData["Message"] = $"{firstDoubleOperand} - {secondDoubleOperand} = {result}";
            
            return View();
        }

        [HttpPost]
        public IActionResult Multiply(string firstOperand, string secondOperand){

            double firstDoubleOperand = Convert.ToDouble(firstOperand);
            double secondDoubleOperand = Convert.ToDouble(secondOperand);
            double result = firstDoubleOperand * secondDoubleOperand;
            
            ViewData["Message"] = $"{firstDoubleOperand} * {secondDoubleOperand} = {result}";
            
            return View();
        }

        [HttpPost]
        public IActionResult Divide(string firstOperand, string secondOperand){

            double firstDoubleOperand = Convert.ToDouble(firstOperand);
            double secondDoubleOperand= Convert.ToDouble(secondOperand);
            double result = firstDoubleOperand / secondDoubleOperand;

            if(secondDoubleOperand == 0.0)
            {
                //string path = @"C:\Temp\files";
                ViewData["Message"] = @"You can't divide by zero";
            }else{
                ViewData["Message"] = $"{firstDoubleOperand} / {secondDoubleOperand} = {result}";
            }
            
            return View();
        }

        [HttpPost]
        public IActionResult Modulus(string firstOperand, string secondOperand){

            double firstDoubleOperand = Convert.ToDouble(firstOperand);
            double secondDoubleOperand = Convert.ToDouble(secondOperand);
            double result = firstDoubleOperand % secondDoubleOperand;
            
            ViewData["Message"] = $"{firstDoubleOperand} % {secondDoubleOperand} = {result}";
            
            return View();
        }
    }
}
