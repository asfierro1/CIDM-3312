﻿using System;
using System.Text;

namespace Nickname_Generator
{
    class Program
    {
        public static string[] nickNames = new string[30];
        public static int index = 0;
        public static string Name = "";
        public static bool Error = false;
        public static Random pickName = new Random();
        
        /* This public method will initialize and fill in nicknames for the
         * nickNames string array. */
        public static void intializeNickNames()
        {
            nickNames[0] = "RZA Rizzy Rizz";
            nickNames[1] = "GZA/Genius";
            nickNames[2] = "Ol' Dirty Bastard";
            nickNames[3] = "Method Man";
            nickNames[4] = "Raekwon The Master";
            nickNames[5] = "Ghostface";
            nickNames[6] = "Inspectah Deck";
            nickNames[7] = "U-God, I Believe";
            nickNames[8] = "Masta Killa";
            nickNames[9] = "Masta Flash";
            nickNames[10] = "12 O'Clock On The Dot";

            nickNames[11] = "Shinobi";
            nickNames[12] = "Filthy Beat Box Master";
            nickNames[13] = "Snoop Lion";
            nickNames[15] = "Busta Rhymes";
            nickNames[16] = "Eminem The Playa";
            nickNames[17] = "4th Disciple";
            nickNames[18] = "60 Second Assassin";
            nickNames[19] = "9Th Prince";
            nickNames[20] = "Allah Mathematics";

            nickNames[21] = "Baretta 9......Silence";
            nickNames[22] = "Blue Rasperry";
            nickNames[23] = "Bronze Nazareth";
            nickNames[24] = "Cappdonna Of The Dons";
            nickNames[25] = "P.R. Terroist";
            nickNames[26] = "L.A.D. LA The Darkman";
            nickNames[27] = "Xpert Desperado";
            nickNames[28] = "Killa Sin of Repentance";
            nickNames[29] = "Ninja of Wu!";
        }

        /* The method generateName() generates a Wu-Tang nickname for the user.
         * This method first produces a random number and that number will pick the index
         * in the nickNames two-dimenstional array. */
        public static void generateName(string userName)
        {
            //Have the pickName Random object randomly pick a number.
            index = pickName.Next(0,31);

            //Show the user his chosen Wu-Tang nickname.
            Console.WriteLine("Your Wu-Tang nickname is: {0}", nickNames[index]);    
        }


        public static void Main(string[] args)
        {
            //This intialises the nickNames string array.
            intializeNickNames();

            // We must make sure that the user enters in proper input into the program.
            do
            {
                try
                {
                    //Have the user enter in his name
                    Console.WriteLine("Your name:");
                    Error = false;
                    Name = Console.ReadLine();
                }
                catch (FormatException FE)
                {
                    //We have detected an error and must make the user recorrect his input.
                    Error = true;
                    Console.WriteLine(FE.Message);
                }
            }while (Error);

            //Choose a nickname for the user.
            Console.WriteLine("\nYour name is: {0}", Name);
            generateName(Name);
            Console.WriteLine("\nProgram has been terminated!!!!" +
                              "\nCongratulations, you are now a part of The Wu-Tang Clan." +
                              "\nWear The Wu with pride!!!!\n");
        }
    }
}